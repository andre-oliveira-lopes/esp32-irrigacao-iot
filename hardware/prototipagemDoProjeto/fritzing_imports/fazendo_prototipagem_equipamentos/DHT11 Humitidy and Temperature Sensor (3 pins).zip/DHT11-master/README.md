# DHT11
DHT11 Humidity and Temperature Sensor (3 pins) for Fritzing
